const express = require("express");
const router = express.Router();
const rakuten = require("../controllers/rakuten.controller.js");

router.post("/get_info", rakuten.getInfo);

module.exports = router;
