let email = 'yamaha@gmail.com';async function init() {
    
			let nameArr = document.getElementsByClassName("elName")[2].innerHTML.split(" ");
			let name = nameArr[0] + " " + nameArr[1];
			let currentPrice = document.getElementsByClassName("elPriceNumber")[0].innerHTML.replace(",", "");
		
			let janCode,y_img_url;
		
			let yahooToken = "1571d294868bc45f11a3353708aad795c";
			let _url = "https://shopifyproxy.herokuapp.com/webservice.valuecommerce.ne.jp/productdb/search" + 
						"?token=" + yahooToken + 
						"&keyword=" + encodeURI(name) + 
						"&ec_code=0hzmc,0m5af" + 
						"&price_min=" + 500 + 
						"&format=json" + 
						"&sort_by=price" + 
						"&sort_order=asc";
		
			const res = await fetch(_url);
			let temp = await res.json();
			let items = temp.items;
			if (items !== undefined && items.length) {
				for (let i of items) {
					if (i.janCode != "") {
						janCode = i.janCode;
						break;
					}
				}
				y_img_url = items[0].imageSmall.url;
			} else {
				janCode = "";
				y_img_url = "";
			}
			
			console.log(janCode);
			
			let inject = 
			'<form method="get" action="https://keepaautobuy.xsrv.jp/mypage/individual">' + 
				'<div class="form-group">' +
					'<label for="target-price">目標価格</label>' + 
					'<input type="number" class="form-control" id="target-price" name="target-price" placeholder="1000" value="" style="width: 150px !important;" />円になったら通知する' + 
					'<input type="hidden" name="email" value="' + email + '" />' + 
					'<input type="hidden" name="itemName" value="' + name + '" />' + 
					'<input type="hidden" name="itemCode" value="' + janCode + '" />' + 
					'<input type="hidden" name="current-price" value="' + currentPrice + '" />' + 
					'<input type="hidden" name="img-url" value="' + y_img_url + '" />' + 
					'<button type="submit" class="btn btn-block btn-primary" style="width: 200px !important;">トラッキング登録</button>' + 
				'</div>' +
			'</form>';
			let target = document.getElementById("prcdsp");
			target.innerHTML += inject;
		}
		init();